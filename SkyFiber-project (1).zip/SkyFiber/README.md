# SkyFiber – offline music player (Android)

## Build the APK
1. Install Android Studio (Koala or newer). Open this folder.
2. Let Gradle sync (it downloads dependencies; Studio sets up the Gradle wrapper automatically).
3. Build > Build Bundle(s)/APK(s) > Build APK(s). Result: app/build/outputs/apk/debug/app-debug.apk
4. Copy the APK to your Samsung and install it (allow "install unknown apps").

## Use
- Copy your downloaded songs to the phone's Music folder (any folder works).
- Open SkyFiber, allow audio + notification access. Songs are scanned automatically.
- Playback runs in a foreground media service: keeps playing when the app is closed, shows in the
  notification shade, lock screen and Samsung's media output panel, and responds to Bluetooth/headset buttons.

## Features
Library (songs/albums/artists), search, liked songs, playlists, queue (play next / add to queue),
shuffle, repeat, seek, sleep timer, cover art, and Smart automation:
Smart Mix, Smart autoplay (queue refills itself), Rediscover, On repeat, Fresh adds, Liked mix,
"Smart Mix from this song". Selection learns from plays, likes, skips and time of day.

## What's new in 1.1
- Animations: slide-up full player, animated mini-player with progress bar, dancing equalizer bars on the playing song,
  album-art colour theming in the player, art that shrinks on pause and bounces on play, bouncy card presses,
  like-heart pop, pulsing Smart Mix icon, fade transitions between screens and library tabs.
- Features: playback speed (0.75x-2x), sleep-timer countdown, remove songs from queue / clear upcoming,
  remove songs from playlists, library sorting (A-Z, artist, newest, longest), shuffle-all, search clear + shuffle results,
  album/artist/playlist header with song count and total time, home stats line.
