package com.skyfiber.player

import android.app.Application

class SkyFiberApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}
