package com.skyfiber.player

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Local persistence: likes, playlists, listening stats (used by the Smart automation). */
object Store {
    class Stat(var plays: Int = 0, var skips: Int = 0, var last: Long = 0L, val hours: IntArray = IntArray(24))

    private lateinit var p: SharedPreferences
    private val stats = HashMap<Long, Stat>()
    val favorites = MutableStateFlow<Set<Long>>(emptySet())
    val playlists = MutableStateFlow<Map<String, List<Long>>>(emptyMap())
    val autoplay = MutableStateFlow(true)

    @Synchronized
    fun init(c: Context) {
        if (::p.isInitialized) return
        p = c.getSharedPreferences("skyfiber", Context.MODE_PRIVATE)
        runCatching {
            val js = JSONObject(p.getString("stats", "{}")!!)
            js.keys().forEach { k ->
                val a = js.getJSONArray(k)
                val s = Stat(a.getInt(0), a.getInt(1), a.getLong(2))
                for (h in 0 until 24) s.hours[h] = a.optInt(3 + h, 0)
                stats[k.toLong()] = s
            }
        }
        runCatching {
            val a = JSONArray(p.getString("favs", "[]")!!)
            favorites.value = (0 until a.length()).map { a.getLong(it) }.toSet()
        }
        runCatching {
            val o = JSONObject(p.getString("playlists", "{}")!!)
            val m = LinkedHashMap<String, List<Long>>()
            o.keys().forEach { k -> val a = o.getJSONArray(k); m[k] = (0 until a.length()).map { a.getLong(it) } }
            playlists.value = m
        }
        autoplay.value = p.getBoolean("autoplay", true)
    }

    fun stat(id: Long): Stat? = synchronized(stats) { stats[id] }

    fun recordPlay(id: Long, hour: Int) {
        synchronized(stats) {
            val s = stats.getOrPut(id) { Stat() }
            s.plays++; s.last = System.currentTimeMillis(); s.hours[hour]++
        }
        saveStats()
    }

    fun recordSkip(id: Long) {
        synchronized(stats) { stats.getOrPut(id) { Stat() }.skips++ }
        saveStats()
    }

    private fun saveStats() {
        val js = JSONObject()
        synchronized(stats) {
            stats.forEach { (id, s) ->
                val a = JSONArray().put(s.plays).put(s.skips).put(s.last)
                s.hours.forEach { a.put(it) }
                js.put(id.toString(), a)
            }
        }
        p.edit().putString("stats", js.toString()).apply()
    }

    fun toggleFav(id: Long) {
        favorites.value = if (id in favorites.value) favorites.value - id else favorites.value + id
        p.edit().putString("favs", JSONArray(favorites.value.toList()).toString()).apply()
    }

    private fun savePlaylists() {
        val o = JSONObject()
        playlists.value.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        p.edit().putString("playlists", o.toString()).apply()
    }

    fun createPlaylist(name: String) {
        if (name.isBlank() || name in playlists.value) return
        playlists.value = playlists.value + (name to emptyList()); savePlaylists()
    }

    fun addToPlaylist(name: String, id: Long) {
        val cur = playlists.value[name] ?: return
        if (id in cur) return
        playlists.value = playlists.value + (name to cur + id); savePlaylists()
    }

    fun removeFromPlaylist(name: String, id: Long) {
        val cur = playlists.value[name] ?: return
        playlists.value = playlists.value + (name to cur.filter { it != id }); savePlaylists()
    }

    fun deletePlaylist(name: String) {
        playlists.value = playlists.value - name; savePlaylists()
    }

    fun setAutoplay(b: Boolean) {
        autoplay.value = b; p.edit().putBoolean("autoplay", b).apply()
    }
}
