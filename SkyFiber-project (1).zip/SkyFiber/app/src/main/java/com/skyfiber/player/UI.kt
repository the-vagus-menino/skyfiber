package com.skyfiber.player

import android.graphics.Bitmap
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Calendar

val Sky = Color(0xFF38BDF8)
val Bg = Color(0xFF0B1220)
val Surf = Color(0xFF121B2E)
val CardC = Color(0xFF1A2640)
val Muted = Color(0xFF94A3B8)

@Composable
fun SkyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Sky, onPrimary = Color.Black, background = Bg, onBackground = Color.White,
            surface = Surf, onSurface = Color.White, surfaceVariant = CardC, onSurfaceVariant = Muted,
            secondaryContainer = Color(0xFF1E3A5F), onSecondaryContainer = Color.White
        ), content = content
    )
}

fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

object ArtCache { val c = LruCache<Long, Bitmap>(150) }

fun totalTime(list: List<Song>): String {
    val m = list.sumOf { it.durationMs } / 60000
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

/** Press-down bounce feedback for tappable cards. */
fun Modifier.bouncyClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) .94f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Three dancing bars – shown on the song that is currently playing. */
@Composable
fun EqBars(playing: Boolean, color: Color = Sky, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(.25f, 1f, infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(.3f, 1f, infiniteRepeatable(tween(620, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c by t.animateFloat(.2f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "c")
    Row(modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, c).forEach { h ->
            Box(Modifier.width(3.dp).fillMaxHeight(if (playing) h else .25f).background(color, RoundedCornerShape(1.dp)))
        }
    }
}

/** Picks a colour from the cover art so the player background matches the song. */
@Composable
fun rememberAccent(song: Song?): Color {
    val ctx = LocalContext.current
    val fallback = Color(0xFF0C4A6E)
    val target by produceState(fallback, song?.id) {
        val s = song
        value = if (s == null) fallback else withContext(Dispatchers.IO) {
            runCatching {
                val bm = ctx.contentResolver.loadThumbnail(s.uri, android.util.Size(48, 48), null)
                val one = Bitmap.createScaledBitmap(bm.copy(Bitmap.Config.ARGB_8888, false), 1, 1, true)
                lerp(Color(one.getPixel(0, 0)), Color.Black, .5f)
            }.getOrDefault(fallback)
        }
    }
    val anim by animateColorAsState(target, tween(700), label = "accent")
    return anim
}

@Composable
fun Art(song: Song?, modifier: Modifier = Modifier, px: Int = 256, corner: Dp = 8.dp) {
    val ctx = LocalContext.current
    val key = song?.let { it.id * 2 + if (px > 300) 1 else 0 }
    val bmp by produceState<Bitmap?>(key?.let { ArtCache.c.get(it) }, key) {
        val s = song
        if (s == null || key == null) { value = null; return@produceState }
        ArtCache.c.get(key)?.let { value = it; return@produceState }
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(s.uri, android.util.Size(px, px), null) }.getOrNull()
        }?.also { ArtCache.c.put(key, it) }
    }
    Box(
        modifier.clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF1E3A8A)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = Color.White.copy(alpha = .8f))
    }
}

data class Detail(val title: String, val songs: List<Song>, val playlist: String? = null)

@Composable
fun App(vm: PlayerVM, onRescan: () -> Unit) {
    val songs by vm.songs.collectAsState()
    val now by vm.now.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var full by remember { mutableStateOf(false) }
    BackHandler(full) { full = false }
    BackHandler(detail != null && !full) { detail = null }
    val cur = vm.song(now.id)

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column {
                    AnimatedVisibility(
                        visible = cur != null,
                        enter = slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
                        exit = slideOutVertically { it } + fadeOut()
                    ) {
                        if (cur != null) MiniPlayer(vm, cur, now) { full = true }
                    }
                    NavigationBar(containerColor = Surf) {
                        listOf(Icons.Filled.Home to "Home", Icons.Filled.Search to "Search", Icons.Filled.LibraryMusic to "Library")
                            .forEachIndexed { i, (ic, label) ->
                                NavigationBarItem(
                                    selected = tab == i && detail == null, onClick = { tab = i; detail = null },
                                    icon = { Icon(ic, null) }, label = { Text(label) })
                            }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                val screenKey = if (detail != null) -1 else tab
                AnimatedContent(
                    targetState = screenKey,
                    transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(120)) },
                    label = "screen"
                ) { k ->
                    when (k) {
                        -1 -> detail?.let { d -> DetailScreen(vm, d, now.id) { detail = null } }
                        0 -> HomeScreen(vm, songs, now.id, onRescan) { detail = it }
                        1 -> SearchScreen(vm, songs, now.id)
                        else -> LibraryScreen(vm, songs, now.id) { detail = it }
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = full,
            enter = slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
            exit = slideOutVertically(tween(260)) { it } + fadeOut()
        ) { NowPlaying(vm) { full = false } }
    }
}

@Composable
fun MiniPlayer(vm: PlayerVM, s: Song, st: NowState, open: () -> Unit) {
    var pos by remember { mutableLongStateOf(0L) }
    LaunchedEffect(st.id, st.playing) { while (true) { pos = vm.position(); delay(500) } }
    val target = if (st.duration > 0) (pos.toFloat() / st.duration).coerceIn(0f, 1f) else 0f
    val frac by animateFloatAsState(target, tween(500, easing = LinearEasing), label = "mini-progress")
    Column(Modifier.fillMaxWidth().background(CardC).clickable(onClick = open)) {
        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Sky, trackColor = Color.Transparent)
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(s, Modifier.size(44.dp))
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
            }
            EqBars(st.playing, modifier = Modifier.padding(end = 4.dp))
            IconButton({ vm.togglePlay() }) {
                Crossfade(st.playing, label = "mini-pp") { p ->
                    Icon(if (p) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Sky, modifier = Modifier.size(32.dp))
                }
            }
            IconButton({ vm.next() }) { Icon(Icons.Filled.SkipNext, null) }
        }
    }
}

@Composable
fun SongRow(s: Song, vm: PlayerVM, current: Boolean, onRemove: (() -> Unit)? = null, onClick: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    val favs by Store.favorites.collectAsState()
    val nowSt by vm.now.collectAsState()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(s, Modifier.size(48.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (current) Sky else Color.White, fontWeight = FontWeight.Medium)
            Text("${s.artist} • ${fmt(s.durationMs)}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
        }
        if (current) EqBars(nowSt.playing, modifier = Modifier.padding(end = 6.dp))
        if (s.id in favs) Icon(Icons.Filled.Favorite, null, tint = Sky, modifier = Modifier.size(18.dp))
        Box {
            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Play next") }, { vm.playNext(s); menu = false })
                DropdownMenuItem({ Text("Add to queue") }, { vm.enqueue(s); menu = false })
                DropdownMenuItem({ Text(if (s.id in favs) "Remove from Liked" else "Add to Liked") }, { Store.toggleFav(s.id); menu = false })
                DropdownMenuItem({ Text("Add to playlist") }, { picker = true; menu = false })
                DropdownMenuItem({ Text("Smart Mix from this song") }, { vm.smartMix(s); menu = false })
                if (onRemove != null) DropdownMenuItem({ Text("Remove from this playlist") }, { onRemove(); menu = false })
            }
        }
    }
    if (picker) PlaylistPicker(s, { picker = false })
}

@Composable
fun PlaylistPicker(s: Song, dismiss: () -> Unit) {
    val pls by Store.playlists.collectAsState()
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = dismiss, containerColor = Surf,
        title = { Text("Add to playlist") },
        text = {
            Column {
                pls.keys.forEach { n ->
                    TextButton({ Store.addToPlaylist(n, s.id); dismiss() }) { Text(n) }
                }
                OutlinedTextField(newName, { newName = it }, label = { Text("New playlist") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton({
                if (newName.isNotBlank()) { Store.createPlaylist(newName.trim()); Store.addToPlaylist(newName.trim(), s.id) }
                dismiss()
            }) { Text(if (newName.isBlank()) "Close" else "Create & add") }
        }
    )
}

@Composable
fun HCard(s: Song, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).bouncyClick(onClick)) {
        Art(s, Modifier.size(140.dp), px = 320, corner = 12.dp)
        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun Section(title: String, list: List<Song>, vm: PlayerVM) {
    if (list.isEmpty()) return
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 8.dp))
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(list) { i, s -> HCard(s) { vm.play(list, i) } }
    }
}

@Composable
fun HomeScreen(vm: PlayerVM, songs: List<Song>, curId: Long?, rescan: () -> Unit, open: (Detail) -> Unit) {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = when { hour < 5 -> "Late night"; hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }
    val favs by Store.favorites.collectAsState()
    if (songs.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SkyFiber", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Sky)
            Spacer(Modifier.height(12.dp))
            Text("No songs found yet. Copy your downloaded music into your phone's Music folder, allow audio access, then tap Rescan.", color = Muted)
            Spacer(Modifier.height(16.dp))
            Button(rescan) { Text("Rescan") }
        }
        return
    }
    val recent = remember(songs, curId) { SmartMix.recentlyPlayed(songs, 15) }
    val most = remember(songs, curId) { SmartMix.mostPlayed(songs, 15) }
    val fresh = remember(songs) { SmartMix.freshAdds(songs, 15) }
    val redisc = remember(songs) { SmartMix.rediscover(songs, 15) }
    val pulse = rememberInfiniteTransition(label = "smart-pulse")
    val glow by pulse.animateFloat(1f, 1.18f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0C4A6E).copy(alpha = .55f), Bg)))) {
                Text(greet, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp))
                Text("${songs.size} songs • ${favs.size} liked • ${totalTime(songs)}", color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 16.dp, bottom = 12.dp, top = 2.dp))
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).bouncyClick { vm.smartMix() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0C4A6E)), shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AutoAwesome, null, tint = Sky,
                            modifier = Modifier.size(36.dp).graphicsLayer { scaleX = glow; scaleY = glow })
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text("Smart Mix", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Auto-picked from your likes, plays, skips and time of day", color = Muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Filled.PlayCircle, null, tint = Sky, modifier = Modifier.size(44.dp))
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip({ vm.play(SmartMix.rediscover(songs, 40), 0) }, { Text("Rediscover") })
                    AssistChip({ vm.play(SmartMix.mostPlayed(songs, 40), 0) }, { Text("On repeat") })
                    AssistChip({ vm.play(SmartMix.freshAdds(songs, 40), 0) }, { Text("Fresh adds") })
                    AssistChip({ vm.play(SmartMix.likedMix(songs, 40), 0) }, { Text("Liked mix") })
                    AssistChip({ vm.playShuffled(songs) }, { Text("Shuffle all") })
                }
            }
        }
        item { Section("Jump back in", recent, vm) }
        item { Section("Your top songs", most, vm) }
        item { Section("Recently added", fresh, vm) }
        item { Section("Rediscover", redisc, vm) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun SearchScreen(vm: PlayerVM, songs: List<Song>, curId: Long?) {
    var q by remember { mutableStateOf("") }
    val res = remember(q, songs) {
        if (q.isBlank()) emptyList() else songs.filter {
            it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
            placeholder = { Text("Songs, artists, albums") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Filled.Close, null) } })
        if (q.isNotBlank() && res.isEmpty()) {
            Text("No results for \"$q\"", color = Muted, modifier = Modifier.padding(horizontal = 24.dp))
        } else if (res.isNotEmpty()) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${res.size} results", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton({ vm.play(res.shuffled(), 0) }) { Icon(Icons.Filled.Shuffle, null, Modifier.size(16.dp)); Text(" Shuffle results") }
            }
        }
        LazyColumn { itemsIndexed(res) { i, s -> SongRow(s, vm, s.id == curId) { vm.play(res, i) } } }
    }
}

@Composable
fun LibraryScreen(vm: PlayerVM, songs: List<Song>, curId: Long?, open: (Detail) -> Unit) {
    var mode by remember { mutableIntStateOf(0) }
    var sort by remember { mutableIntStateOf(0) }
    val favs by Store.favorites.collectAsState()
    val pls by Store.playlists.collectAsState()
    var newPl by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val sorted = remember(songs, sort) {
        when (sort) {
            1 -> songs.sortedBy { it.artist.lowercase() }
            2 -> songs.sortedByDescending { it.added }
            3 -> songs.sortedByDescending { it.durationMs }
            else -> songs
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Songs", "Albums", "Artists", "Liked", "Playlists").forEachIndexed { i, t ->
                FilterChip(mode == i, { mode = i }, { Text(t) })
            }
        }
        AnimatedContent(mode, transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(100)) }, label = "lib-mode") { m ->
            when (m) {
                0 -> LazyColumn {
                    item {
                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip({ vm.playShuffled(songs) }, { Text("Shuffle all") }, leadingIcon = { Icon(Icons.Filled.Shuffle, null, Modifier.size(16.dp)) })
                            listOf("A–Z", "Artist", "Newest", "Longest").forEachIndexed { i, t ->
                                FilterChip(sort == i, { sort = i }, { Text(t) })
                            }
                        }
                    }
                    itemsIndexed(sorted) { i, s -> SongRow(s, vm, s.id == curId) { vm.play(sorted, i) } }
                }
                1 -> GroupList(songs.groupBy { it.album }, open)
                2 -> GroupList(songs.groupBy { it.artist }, open)
                3 -> {
                    val liked = songs.filter { it.id in favs }
                    if (liked.isEmpty()) Text("Songs you like will show up here.", color = Muted, modifier = Modifier.padding(24.dp))
                    else LazyColumn { itemsIndexed(liked) { i, s -> SongRow(s, vm, s.id == curId) { vm.play(liked, i) } } }
                }
                else -> LazyColumn {
                    item { TextButton({ newPl = true }, Modifier.padding(horizontal = 8.dp)) { Icon(Icons.Filled.Add, null); Text(" New playlist") } }
                    items(pls.keys.toList()) { n ->
                        val l = pls[n].orEmpty().mapNotNull { id -> songs.find { it.id == id } }
                        ListItem(
                            headlineContent = { Text(n) }, supportingContent = { Text("${l.size} songs") },
                            leadingContent = { Icon(Icons.AutoMirrored.Filled.QueueMusic, null, tint = Sky) },
                            trailingContent = { IconButton({ Store.deletePlaylist(n) }) { Icon(Icons.Filled.Delete, null) } },
                            colors = ListItemDefaults.colors(containerColor = Bg),
                            modifier = Modifier.clickable { open(Detail(n, l, n)) }
                        )
                    }
                }
            }
        }
    }
    if (newPl) AlertDialog(
        onDismissRequest = { newPl = false }, containerColor = Surf, title = { Text("New playlist") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton({ Store.createPlaylist(name.trim()); name = ""; newPl = false }) { Text("Create") } }
    )
}

@Composable
fun GroupList(groups: Map<String, List<Song>>, open: (Detail) -> Unit) {
    val keys = remember(groups) { groups.keys.sorted() }
    LazyColumn {
        items(keys) { k ->
            val l = groups[k].orEmpty()
            ListItem(
                headlineContent = { Text(k, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text("${l.size} songs") },
                leadingContent = { Art(l.first(), Modifier.size(48.dp)) },
                colors = ListItemDefaults.colors(containerColor = Bg),
                modifier = Modifier.clickable { open(Detail(k, l)) }
            )
        }
    }
}

@Composable
fun DetailScreen(vm: PlayerVM, d: Detail, curId: Long?, back: () -> Unit) {
    val pls by Store.playlists.collectAsState()
    val list = if (d.playlist != null) pls[d.playlist].orEmpty().mapNotNull { vm.song(it) } else d.songs
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
            IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(d.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(list.firstOrNull(), Modifier.size(88.dp), px = 320, corner = 12.dp)
            Column(Modifier.padding(start = 16.dp)) {
                Text("${list.size} songs", fontWeight = FontWeight.SemiBold)
                Text(totalTime(list), color = Muted, fontSize = 12.sp)
            }
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.play(list, 0) }) { Icon(Icons.Filled.PlayArrow, null); Text("Play") }
            OutlinedButton({ vm.playShuffled(list) }) { Icon(Icons.Filled.Shuffle, null); Text(" Shuffle") }
        }
        LazyColumn {
            itemsIndexed(list) { i, s ->
                SongRow(s, vm, s.id == curId, onRemove = d.playlist?.let { p -> { Store.removeFromPlaylist(p, s.id) } }) { vm.play(list, i) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlaying(vm: PlayerVM, close: () -> Unit) {
    val st by vm.now.collectAsState()
    val queue by vm.queue.collectAsState()
    val favs by Store.favorites.collectAsState()
    val auto by Store.autoplay.collectAsState()
    val sleep by SleepTimer.endsAt.collectAsState()
    val song = vm.song(st.id)
    val accent = rememberAccent(song)
    var pos by remember { mutableLongStateOf(0L) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    var sleepMenu by remember { mutableStateOf(false) }
    var speedMenu by remember { mutableStateOf(false) }
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.id, st.playing) {
        while (true) { if (drag == null) pos = vm.position(); delay(400) }
    }
    LaunchedEffect(sleep) {
        while (sleep != null) { clock = System.currentTimeMillis(); delay(1000) }
    }
    val artScale by animateFloatAsState(
        if (st.playing) 1f else .86f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "art-scale"
    )
    val liked = song != null && song.id in favs
    val heart = remember { Animatable(1f) }
    LaunchedEffect(liked, st.id) {
        if (liked) { heart.snapTo(1.5f); heart.animateTo(1f, spring(Spring.DampingRatioMediumBouncy)) }
    }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent, Bg)))
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(close) { Icon(Icons.Filled.KeyboardArrowDown, null, modifier = Modifier.size(32.dp)) }
            Text("Now playing", Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(12.dp))
        Crossfade(song, animationSpec = tween(400), label = "art") { s ->
            Art(s, Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer { scaleX = artScale; scaleY = artScale },
                px = 600, corner = 16.dp)
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Crossfade(song, animationSpec = tween(300), label = "title") { s ->
                    Column {
                        Text(s?.title ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s?.artist ?: "", color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            IconButton({ song?.let { Store.toggleFav(it.id) } }) {
                Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                    tint = if (liked) Sky else Color.White,
                    modifier = Modifier.graphicsLayer { scaleX = heart.value; scaleY = heart.value })
            }
        }
        Slider(
            value = (drag ?: pos.toFloat()).coerceAtMost(maxOf(1f, st.duration.toFloat())),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
            valueRange = 0f..maxOf(1f, st.duration.toFloat())
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt((drag ?: pos.toFloat()).toLong()), color = Muted, fontSize = 12.sp)
            Text(fmt(st.duration), color = Muted, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.toggleShuffle() }) { Icon(Icons.Filled.Shuffle, null, tint = if (st.shuffle) Sky else Color.White) }
            IconButton({ vm.prev() }) { Icon(Icons.Filled.SkipPrevious, null, modifier = Modifier.size(40.dp)) }
            Box(Modifier.size(68.dp).clip(CircleShape).background(Sky).bouncyClick { vm.togglePlay() }, contentAlignment = Alignment.Center) {
                Crossfade(st.playing, label = "big-pp") { p ->
                    Icon(if (p) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(40.dp))
                }
            }
            IconButton({ vm.next() }) { Icon(Icons.Filled.SkipNext, null, modifier = Modifier.size(40.dp)) }
            IconButton({ vm.cycleRepeat() }) {
                Icon(if (st.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null,
                    tint = if (st.repeat != Player.REPEAT_MODE_OFF) Sky else Color.White)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ showQueue = true }) { Icon(Icons.AutoMirrored.Filled.QueueMusic, null) }
            IconButton({ Store.setAutoplay(!auto) }) { Icon(Icons.Filled.AutoAwesome, null, tint = if (auto) Sky else Color.White) }
            Box {
                IconButton({ speedMenu = true }) { Icon(Icons.Filled.Speed, null, tint = if (st.speed != 1f) Sky else Color.White) }
                DropdownMenu(speedMenu, { speedMenu = false }) {
                    listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { sp ->
                        DropdownMenuItem({ Text("Speed ${sp}x" + if (sp == st.speed) "  ✓" else "") }, { vm.setSpeed(sp); speedMenu = false })
                    }
                }
            }
            Box {
                IconButton({ sleepMenu = true }) { Icon(Icons.Filled.Bedtime, null, tint = if (sleep != null) Sky else Color.White) }
                DropdownMenu(sleepMenu, { sleepMenu = false }) {
                    listOf(0 to "Off", 15 to "15 minutes", 30 to "30 minutes", 45 to "45 minutes", 60 to "1 hour").forEach { (m, l) ->
                        DropdownMenuItem({ Text("Sleep timer: $l") }, { vm.setSleep(m); sleepMenu = false })
                    }
                }
            }
        }
        val left = sleep?.let { (it - clock).coerceAtLeast(0L) }
        Text(
            (if (auto) "Smart autoplay on" else "Smart autoplay off") +
                (if (st.speed != 1f) " • ${st.speed}x" else "") +
                (if (left != null) " • Sleep in ${fmt(left)}" else ""),
            color = Muted, fontSize = 11.sp
        )
    }
    if (showQueue) ModalBottomSheet({ showQueue = false }, containerColor = Surf) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Queue", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ vm.clearUpcoming() }) { Text("Clear upcoming") }
        }
        LazyColumn(Modifier.heightIn(max = 480.dp)) {
            itemsIndexed(queue) { i, s ->
                val cur = s.id == st.id
                Row(
                    Modifier.fillMaxWidth().clickable { vm.jumpTo(i) }.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Art(s, Modifier.size(44.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (cur) Sky else Color.White, fontWeight = FontWeight.Medium)
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, fontSize = 12.sp)
                    }
                    if (cur) EqBars(st.playing, modifier = Modifier.padding(end = 6.dp))
                    else IconButton({ vm.removeFromQueue(i) }) { Icon(Icons.Filled.Close, null, tint = Muted) }
                }
            }
        }
    }
}
