package com.skyfiber.player

import java.util.Calendar
import kotlin.math.ln
import kotlin.math.min
import kotlin.random.Random

/**
 * SkyFiber's automatic song selection. It learns from what you do:
 *  - plays, likes and skips
 *  - the hour of day you usually listen to each song
 *  - discovery boost for never-played songs, rediscovery boost for forgotten favourites
 *  - recently played songs are held back so the mix does not repeat
 *  - similarity to a seed song (same artist / album)
 */
object SmartMix {
    private fun hour() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    private const val DAY = 86_400_000L

    fun score(s: Song, seed: Song?, now: Long = System.currentTimeMillis()): Double {
        val st = Store.stat(s.id)
        val h = hour()
        var sc = 1.0
        if (st != null) {
            sc += ln(1.0 + st.plays) * 1.5
            sc -= st.skips * 1.2
            val aff = st.hours[h] + 0.5 * st.hours[(h + 23) % 24] + 0.5 * st.hours[(h + 1) % 24]
            sc += min(aff, 6.0) * 0.6
            if (st.last > 0 && now - st.last < 2 * 3_600_000L) sc -= 4.0
            if (st.plays >= 2 && st.last > 0 && now - st.last > 14 * DAY) sc += 2.0
        } else sc += 1.5
        if (s.id in Store.favorites.value) sc += 3.0
        if (seed != null) {
            if (s.artist == seed.artist) sc += 3.0
            if (s.album == seed.album) sc += 2.0
        }
        return sc + Random.nextDouble() * 2.0
    }

    fun mix(songs: List<Song>, n: Int, seed: Song? = null): List<Song> {
        val ranked = songs.sortedByDescending { score(it, seed) }.filter { it.id != seed?.id }.take(n)
        return if (seed != null && songs.any { it.id == seed.id }) listOf(seed) + ranked.take(n - 1) else ranked
    }

    fun rediscover(songs: List<Song>, n: Int): List<Song> {
        val now = System.currentTimeMillis()
        return songs.filter { val st = Store.stat(it.id); st == null || now - st.last > 14 * DAY }
            .shuffled().take(n)
    }

    fun mostPlayed(songs: List<Song>, n: Int) =
        songs.filter { (Store.stat(it.id)?.plays ?: 0) > 0 }.sortedByDescending { Store.stat(it.id)!!.plays }.take(n)

    fun recentlyPlayed(songs: List<Song>, n: Int) =
        songs.filter { (Store.stat(it.id)?.last ?: 0L) > 0 }.sortedByDescending { Store.stat(it.id)!!.last }.take(n)

    fun freshAdds(songs: List<Song>, n: Int) = songs.sortedByDescending { it.added }.take(n)

    fun likedMix(songs: List<Song>, n: Int) = songs.filter { it.id in Store.favorites.value }.shuffled().take(n)
}
