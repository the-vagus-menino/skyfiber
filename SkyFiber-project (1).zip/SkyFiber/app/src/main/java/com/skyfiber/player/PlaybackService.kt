package com.skyfiber.player

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.BitmapLoader
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Calendar
import java.util.concurrent.Callable
import java.util.concurrent.Executors

object SleepTimer { val endsAt = MutableStateFlow<Long?>(null) }

/** Loads cover art for the notification / lock screen / Samsung media output panel. */
class ThumbLoader(private val ctx: Context) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
    override fun supportsMimeType(mimeType: String) = true
    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> =
        exec.submit(Callable { BitmapFactory.decodeByteArray(data, 0, data.size) })
    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> =
        exec.submit(Callable { ctx.contentResolver.loadThumbnail(uri, Size(512, 512), null) })
}

class PlaybackService : MediaSessionService() {

    companion object { const val SLEEP = "com.skyfiber.SLEEP" }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(
                old: Player.PositionInfo, new: Player.PositionInfo, reason: Int
            ) {
                val id = old.mediaItem?.mediaId?.toLongOrNull() ?: return
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                when (reason) {
                    Player.DISCONTINUITY_REASON_AUTO_TRANSITION -> Store.recordPlay(id, hour)
                    Player.DISCONTINUITY_REASON_SEEK ->
                        if (old.mediaItem?.mediaId != new.mediaItem?.mediaId) {
                            if (old.positionMs < 30_000) Store.recordSkip(id) else Store.recordPlay(id, hour)
                        }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = topUp()
        })
        session = MediaSession.Builder(this, player)
            .setCallback(Callback())
            .setBitmapLoader(ThumbLoader(this))
            .build()
    }

    /** Smart autoplay: when the queue is nearly finished, append songs picked by SmartMix. */
    private fun topUp() {
        if (!Store.autoplay.value || player.repeatMode != Player.REPEAT_MODE_OFF || player.shuffleModeEnabled) return
        if (player.mediaItemCount - player.currentMediaItemIndex > 3) return
        Thread {
            val all = Library.ensure(this)
            handler.post {
                val inQueue = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId }.toSet()
                val seed = all.find { it.id.toString() == player.currentMediaItem?.mediaId }
                val picks = SmartMix.mix(all.filter { it.id.toString() !in inQueue }, 10, seed)
                if (picks.isNotEmpty()) player.addMediaItems(picks.map { it.toItem() })
            }
        }.start()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(SLEEP, Bundle.EMPTY)).build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == SLEEP) {
                val min = args.getInt("min", 0)
                handler.removeCallbacksAndMessages("sleep")
                if (min <= 0) SleepTimer.endsAt.value = null
                else {
                    SleepTimer.endsAt.value = System.currentTimeMillis() + min * 60_000L
                    handler.postAtTime({
                        player.pause(); SleepTimer.endsAt.value = null
                    }, "sleep", android.os.SystemClock.uptimeMillis() + min * 60_000L)
                }
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        override fun onAddMediaItems(
            mediaSession: MediaSession, controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val fixed = mediaItems.map { item ->
                val id = item.mediaId.toLongOrNull()
                if (id != null) item.buildUpon().setUri(
                    ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                ).build() else item
            }.toMutableList()
            return Futures.immediateFuture(fixed)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Keep playing when the app is swiped away; only stop if nothing is playing. */
    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0 || p.playbackState == Player.STATE_ENDED) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
