package com.skyfiber.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val added: Long
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    fun toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(uri) // resolved to a thumbnail by ThumbLoader in the service
                .setIsPlayable(true)
                .build()
        ).build()
}

data class NowState(
    val id: Long? = null,
    val playing: Boolean = false,
    val shuffle: Boolean = false,
    val repeat: Int = 0,
    val duration: Long = 0L,
    val speed: Float = 1f
)

object Library {
    @Volatile var songs: List<Song> = emptyList()

    fun scan(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        runCatching {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                    out += Song(c.getLong(0), c.getString(1) ?: "Unknown", artist,
                        c.getString(3) ?: "Unknown album", c.getLong(4), c.getLong(5), c.getLong(6))
                }
            }
        }
        return out
    }

    fun ensure(ctx: Context): List<Song> {
        if (songs.isEmpty()) songs = scan(ctx)
        return songs
    }
}
