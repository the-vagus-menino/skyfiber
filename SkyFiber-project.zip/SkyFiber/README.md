# SkyFiber – offline music player (Android)

## Build the APK
1. Install Android Studio (Koala or newer). Open this folder.
2. Let Gradle sync (it downloads dependencies; Studio sets up the Gradle wrapper automatically).
3. Build > Build Bundle(s)/APK(s) > Build APK(s). Result: app/build/outputs/apk/debug/app-debug.apk
4. Copy the APK to your Samsung and install it (allow "install unknown apps").

## Use
- Copy your downloaded songs to the phone's Music folder (any folder works).
- Open SkyFiber, allow audio + notification access. Songs are scanned automatically.
- Playback runs in a foreground media service: keeps playing when the app is closed, shows in the
  notification shade, lock screen and Samsung's media output panel, and responds to Bluetooth/headset buttons.

## Features
Library (songs/albums/artists), search, liked songs, playlists, queue (play next / add to queue),
shuffle, repeat, seek, sleep timer, cover art, and Smart automation:
Smart Mix, Smart autoplay (queue refills itself), Rediscover, On repeat, Fresh adds, Liked mix,
"Smart Mix from this song". Selection learns from plays, likes, skips and time of day.
