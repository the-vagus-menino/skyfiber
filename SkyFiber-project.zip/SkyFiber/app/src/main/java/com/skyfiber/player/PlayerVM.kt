package com.skyfiber.player

import android.app.Application
import android.content.ComponentName
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerVM(app: Application) : AndroidViewModel(app) {
    val songs = MutableStateFlow<List<Song>>(emptyList())
    val now = MutableStateFlow(NowState())
    val queue = MutableStateFlow<List<Song>>(emptyList())
    private var byId: Map<Long, Song> = emptyMap()
    private var c: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh(events.contains(Player.EVENT_TIMELINE_CHANGED))
        }
    }

    init {
        Store.init(app)
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            runCatching { c = f.get().also { it.addListener(listener) } }
            refresh(true)
        }, ContextCompat.getMainExecutor(app))
    }

    fun loadLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val s = Library.scan(getApplication())
            Library.songs = s
            byId = s.associateBy { it.id }
            songs.value = s
            withContext(Dispatchers.Main) { refresh(true) }
        }
    }

    private fun refresh(q: Boolean) {
        val p = c ?: return
        now.value = NowState(
            p.currentMediaItem?.mediaId?.toLongOrNull(),
            p.isPlaying || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING),
            p.shuffleModeEnabled, p.repeatMode,
            p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        )
        if (q) queue.value = (0 until p.mediaItemCount).mapNotNull { byId[p.getMediaItemAt(it).mediaId.toLongOrNull()] }
    }

    fun song(id: Long?) = id?.let { byId[it] }
    fun position() = c?.currentPosition ?: 0L

    fun play(list: List<Song>, index: Int) {
        val p = c ?: return
        if (list.isEmpty()) return
        val start = (index - 50).coerceAtLeast(0)
        val window = list.subList(start, (start + 300).coerceAtMost(list.size))
        p.setMediaItems(window.map { it.toItem() }, index - start, 0L)
        p.prepare(); p.play()
    }

    fun playShuffled(list: List<Song>) = play(list.shuffled(), 0)
    fun smartMix(seed: Song? = null) = play(SmartMix.mix(songs.value, 40, seed), 0)

    fun togglePlay() {
        val p = c ?: return
        if (p.isPlaying) p.pause() else { if (p.playbackState == Player.STATE_IDLE) p.prepare(); p.play() }
    }
    fun next() { c?.seekToNext() }
    fun prev() { c?.seekToPrevious() }
    fun seek(ms: Long) { c?.seekTo(ms) }
    fun jumpTo(i: Int) { c?.seekTo(i, 0L); c?.play() }
    fun toggleShuffle() { c?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        c?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun playNext(s: Song) {
        val p = c ?: return
        if (p.mediaItemCount == 0) play(listOf(s), 0) else p.addMediaItem(p.currentMediaItemIndex + 1, s.toItem())
    }
    fun enqueue(s: Song) {
        val p = c ?: return
        if (p.mediaItemCount == 0) play(listOf(s), 0) else p.addMediaItem(s.toItem())
    }
    fun setSleep(min: Int) {
        c?.sendCustomCommand(SessionCommand(PlaybackService.SLEEP, Bundle.EMPTY), Bundle().apply { putInt("min", min) })
    }

    override fun onCleared() { c?.release(); super.onCleared() }
}
